import gnu.trove.procedure.TIntProcedure;

import java.io.IOException;
import java.util.*;
        
import net.sf.jsi.Rectangle;
import net.sf.jsi.SpatialIndex;
import net.sf.jsi.rtree.RTree;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import diewald_shapeFile.files.dbf.DBF_Field;
import diewald_shapeFile.files.dbf.DBF_File;
import diewald_shapeFile.files.shp.SHP_File;
import diewald_shapeFile.files.shp.shapeTypes.ShpPolygon;
import diewald_shapeFile.files.shp.shapeTypes.ShpShape;
import diewald_shapeFile.files.shx.SHX_File;
import diewald_shapeFile.shapeFile.ShapeFile;
        
public class WordCount {
        
 public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();
    private String[] token;
    private SpatialIndex si;
    private HashMap<Integer,String> m;
    
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        setupShapeFileConfig();
    	String line = value.toString();
        token = line.split(",");
        System.out.println(token.toString());
        System.out.flush();
        
        SaveToListProcedure myProc = new SaveToListProcedure();
        
        si.intersects(new Rectangle(-73.9819299f, 40.7264449f, -73.9819299f, 40.7264449f),myProc);
        
        List<Integer> ids = myProc.getIds();
        //System.out.println("size :: " + ids.size());
        for (Integer id : ids) {
          //log.info(rects[id].toString() + " was contained");
          //System.out.println(m.get(id));
        }

        StringTokenizer tokenizer = new StringTokenizer(line);
        while (tokenizer.hasMoreTokens()) {
	    String temp = tokenizer.nextToken();
	    if(temp.length() == 5){ 
            	word.set(temp);
            	context.write(word, one);
	    }        
	}
        
    }
    
    public void setupShapeFileConfig(){
        DBF_File.LOG_INFO           = !false;
        DBF_File.LOG_ONLOAD_HEADER  = false;
        DBF_File.LOG_ONLOAD_CONTENT = false;
        
        SHX_File.LOG_INFO           = !false;
        SHX_File.LOG_ONLOAD_HEADER  = false;
        SHX_File.LOG_ONLOAD_CONTENT = false;
        
        SHP_File.LOG_INFO           = !false;
        SHP_File.LOG_ONLOAD_HEADER  = false;
        SHP_File.LOG_ONLOAD_CONTENT = false;
        
        si = new RTree();
        si.init(null);
    	m = new HashMap<Integer, String>();
        Set<String> s = new HashSet<String>();
        s.add("New York");
        s.add("Kings");
        s.add("Queens");
        s.add("Bronx");
        

        try {
          // GET DIRECTORY
          String curDir = System.getProperty("user.dir");
          String folder = "/zillow/";
          
          // LOAD SHAPE FILE (.shp, .shx, .dbf)
          ShapeFile shapefile = new ShapeFile(curDir+folder, "ZillowNeighborhoods-NY").READ();
          
          // TEST: printing some content
          ShpShape.Type shape_type = shapefile.getSHP_shapeType();
          //System.out.println("\nshape_type = " +shape_type);
        
          int number_of_shapes = shapefile.getSHP_shapeCount();
          int number_of_fields = shapefile.getDBF_fieldCount();
          for(int i = 0; i < number_of_shapes; i++){
            ShpPolygon shape    = shapefile.getSHP_shape(i);
            String[] shape_info = shapefile.getDBF_record(i);
      
            ShpShape.Type type     = shape.getShapeType();
            int number_of_vertices = shape.getNumberOfPoints();
            int number_of_polygons = shape.getNumberOfParts();
            int record_number      = shape.getRecordNumber();
            double[][] list = shape.getBoundingBox();
            
            //System.out.printf("\nSHAPE[%2d] - %s\n", i, type);
            //System.out.printf("  (shape-info) record_number = %3d; vertices = %6d; polygons = %2d\n", record_number, number_of_vertices, number_of_polygons);
            
            String check="";
            for(int j = 0; j < number_of_fields; j++){
              String data = shape_info[j].trim();
              DBF_Field field = shapefile.getDBF_field(j);
              String field_name = field.getName();
              if(j==3){
            	  if(s.contains(check)){
            		  m.put(i,data);
                	  Rectangle rects = new Rectangle((float)list[0][0],(float)list[1][0],(float)list[0][1],(float)list[1][1]);
                      si.add(rects,i);
                  }
              }
              if(j==1)
            	  check=data;
              //System.out.printf("  (dbase-info) [%d] %s = %s", j, field_name, data);
            
            }
            //System.out.printf("\n");
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
    }
    
    class SaveToListProcedure implements TIntProcedure {
        private List<Integer> ids = new ArrayList<Integer>();

        public boolean execute(int id) {
          ids.add(id);
          return true;
        }; 
        
        private List<Integer> getIds() {
          return ids;
        }
      };

 }
 
  public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {

    public void reduce(Text key, Iterable<IntWritable> values, Context context) 
      throws IOException, InterruptedException {
        int sum = 0;
        for (IntWritable val : values) {
            sum += val.get();
        }
        context.write(key, new IntWritable(sum));
    }
 }
        
 public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
        
    Job job = new Job(conf, "wordcount");
    
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
        
    job.setMapperClass(Map.class);
    job.setReducerClass(Reduce.class);
        
    job.setInputFormatClass(TextInputFormat.class);
    job.setOutputFormatClass(TextOutputFormat.class);

    job.setNumReduceTasks(1);
    job.setJarByClass(WordCount.class);
        
    FileInputFormat.addInputPath(job, new Path(args[1]));
    FileOutputFormat.setOutputPath(job, new Path(args[2]));
    
    job.waitForCompletion(true);
 }
        
}