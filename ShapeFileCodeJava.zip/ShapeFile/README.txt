Compile
-------

    javac -cp hadoop-1.0.3/hadoop-core-1.0.3.jar WordCount.java

Create jar file
---------------

    jar cvf WordCount.jar *.class

    # or

    zip -r WordCount.jar *.class

Run
---

    cd hadoop-1.0.3/
    bin/hadoop jar ../WordCount.jar WordCount ../input ../output







javac -cp jsi-1.0.0.jar:jsi-1.0.0-javadoc.jar:jsi-1.0.0-sources.jar:slf4j-api-1.6.3.jar:trove-3.1a1.jar:net.jar:diewald_shapeFileReader.jar:../../hadoop-core-1.0.3.jar ../WordCount.java

create jar [jarfolder]

jar -cvf WordCount.jar *

run

../bin/hadoop jar WordCount.jar WordCount input/ output/
