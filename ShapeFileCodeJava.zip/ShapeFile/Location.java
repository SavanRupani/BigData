import gnu.trove.procedure.TIntProcedure;

import java.io.IOException;
import java.util.*;
        
import net.sf.jsi.Rectangle;
import net.sf.jsi.SpatialIndex;
import net.sf.jsi.rtree.RTree;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import diewald_shapeFile.files.dbf.DBF_Field;
import diewald_shapeFile.files.dbf.DBF_File;
import diewald_shapeFile.files.shp.SHP_File;
import diewald_shapeFile.files.shp.shapeTypes.ShpPolygon;
import diewald_shapeFile.files.shp.shapeTypes.ShpShape;
import diewald_shapeFile.files.shx.SHX_File;
import diewald_shapeFile.shapeFile.ShapeFile;
        
public class WordCount {
        
 public static class Map extends Mapper<LongWritable, Text, Text, Text> {
    private Text word = new Text();
    private Text val = new Text();
    private String[] token;
    private SpatialIndex si;
    private HashMap<Integer,String> m;
    
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        setupShapeFileConfig();
    	String line = value.toString();
        token = line.split(",");
        SaveToListProcedure myProc = new SaveToListProcedure();
        try{
        	si.intersects(new Rectangle(Float.parseFloat(token[10]),Float.parseFloat(token[11]),Float.parseFloat(token[10]),Float.parseFloat(token[11])),myProc);
        
        List<Integer> ids = myProc.getIds();
        	if(ids.size()>=1){
			System.out.println(token[10] +","+token[11]+","+m.get(ids.get(0)));
			word.set(token[10] +","+token[11]+","+m.get(ids.get(0)));
			val.set("");
			context.write(word,val);
		} 
        }catch(Exception ex){
		System.out.println("Error");
		System.out.flush();
	}
    }
    
    public void setupShapeFileConfig(){
        DBF_File.LOG_INFO           = false;
        DBF_File.LOG_ONLOAD_HEADER  = false;
        DBF_File.LOG_ONLOAD_CONTENT = false;
        
        SHX_File.LOG_INFO           = false;
        SHX_File.LOG_ONLOAD_HEADER  = false;
        SHX_File.LOG_ONLOAD_CONTENT = false;
        
        SHP_File.LOG_INFO           = false;
        SHP_File.LOG_ONLOAD_HEADER  = false;
        SHP_File.LOG_ONLOAD_CONTENT = false;
        
        si = new RTree();
        si.init(null);
    	m = new HashMap<Integer, String>();
        
	System.out.println("1");
			
        try {
          // GET DIRECTORY
          //String curDir = System.getProperty("user.dir");
          //String folder = "/zny/";
          ShapeFile shapefile=null;
          // LOAD SHAPE FILE (.shp, .shx, .dbf)
		try{
			System.out.println("2");
	          
			shapefile = new ShapeFile("", "zny").READ();
		}catch(Exception Ex ){
			System.out.println("File Error");
		}
          System.out.println("3");
	
	 // TEST: printing some content
          ShpShape.Type shape_type = shapefile.getSHP_shapeType();
          
          int number_of_shapes = shapefile.getSHP_shapeCount();
          int number_of_fields = shapefile.getDBF_fieldCount();
          for(int i = 0; i < number_of_shapes; i++){
            ShpPolygon shape    = shapefile.getSHP_shape(i);
            String[] shape_info = shapefile.getDBF_record(i);
      
            ShpShape.Type type     = shape.getShapeType();
            int number_of_vertices = shape.getNumberOfPoints();
            int number_of_polygons = shape.getNumberOfParts();
            int record_number      = shape.getRecordNumber();
            double[][] list = shape.getBoundingBox();
            
            String check="";
            for(int j = 0; j < number_of_fields; j++){
              String data = shape_info[j].trim();
              DBF_Field field = shapefile.getDBF_field(j);
              String field_name = field.getName();
              if(j==3){
		m.put(i,data);
		Rectangle rects = new Rectangle((float)list[0][0],(float)list[1][0],(float)list[0][1],(float)list[1][1]);
		si.add(rects,i);
               check=data;
              }
            }
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
    }
    
    class SaveToListProcedure implements TIntProcedure {
        private List<Integer> ids = new ArrayList<Integer>();

        public boolean execute(int id) {
          ids.add(id);
          return true;
        }; 
        
        private List<Integer> getIds() {
          return ids;
        }
      };

 }
 
  public static class Reduce extends Reducer<Text,Text, Text,Text> {

    public void reduce(Text key,Text values, Context context) 
      throws IOException, InterruptedException {
        context.write(key,values);
    }
 }
        
 public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
        
    Job job = new Job(conf, "GetReg");
    
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
        
    job.setMapperClass(Map.class);
    job.setReducerClass(Reduce.class);
        
    job.setInputFormatClass(TextInputFormat.class);
    job.setOutputFormatClass(TextOutputFormat.class);

    job.setJarByClass(WordCount.class);
        
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    
    job.waitForCompletion(true);
 }
        
}
